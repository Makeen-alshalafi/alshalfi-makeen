# 📚 دليل تشغيل مشروع Portfolio على جهازك

## المتطلبات الأساسية

قبل البدء، تأكد من تثبيت البرامج التالية على جهازك:

### 1. Node.js و npm
- **تحميل:** https://nodejs.org/
- **اختر الإصدار:** LTS (Long Term Support)
- **التحقق من التثبيت:**
```bash
node --version
npm --version
```

### 2. Git (اختياري لكن موصى به)
- **تحميل:** https://git-scm.com/
- **التحقق من التثبيت:**
```bash
git --version
```

---

## خطوات التشغيل خطوة بخطوة

### الخطوة 1: استنساخ المشروع من GitHub

```bash
git clone https://github.com/Makeen-alshalafi/alshalfi-makeen.git
cd alshalfi-makeen
```

**أو** إذا لم تكن تملك Git:
- اذهب إلى: https://github.com/Makeen-alshalafi/alshalfi-makeen
- اضغط على **Code** → **Download ZIP**
- فك ضغط الملف واستخرج المجلد
- افتح Terminal/Command Prompt وانتقل إلى مجلد المشروع

---

### الخطوة 2: تثبيت المتطلبات

افتح Terminal/Command Prompt في مجلد المشروع وشغل:

```bash
npm install
```

أو إذا كنت تستخدم pnpm:

```bash
pnpm install
```

**ملاحظة:** قد يستغرق هذا 5-10 دقائق حسب سرعة الإنترنت.

---

### الخطوة 3: تشغيل المشروع في وضع التطوير

```bash
npm run dev
```

أو مع pnpm:

```bash
pnpm dev
```

**النتيجة المتوقعة:**
```
  ➜  Local:   http://localhost:5173/
  ➜  Network: http://[your-ip]:5173/
```

---

### الخطوة 4: فتح الموقع في المتصفح

انسخ الرابط من الخطوة السابقة والصقه في متصفحك:

```
http://localhost:5173/
```

**تم! 🎉 الموقع الآن يعمل على جهازك**

---

## الأوامر المهمة الأخرى

### بناء المشروع للإنتاج
```bash
npm run build
```

### معاينة البناء
```bash
npm run preview
```

### التحقق من الأخطاء
```bash
npm run check
```

### تنسيق الكود
```bash
npm run format
```

---

## استكشاف الأخطاء الشائعة

### المشكلة: "command not found: npm"
**الحل:** تأكد من تثبيت Node.js بشكل صحيح وأعد تشغيل Terminal

### المشكلة: "Port 5173 is already in use"
**الحل:** غير المنفذ:
```bash
npm run dev -- --port 3000
```

### المشكلة: "node_modules not found"
**الحل:** شغل `npm install` مرة أخرى

### المشكلة: الموقع يظهر أبيض بدون محتوى
**الحل:** 
1. افتح Developer Tools (F12)
2. تحقق من Console للأخطاء
3. أعد تحميل الصفحة (Ctrl+R أو Cmd+R)

---

## بنية المشروع

```
alshalfi-makeen/
├── client/
│   ├── src/
│   │   ├── pages/           # صفحات الموقع
│   │   ├── components/      # المكونات
│   │   │   └── sections/    # أقسام الموقع
│   │   ├── index.css        # الأنماط الرئيسية
│   │   └── App.tsx          # تطبيق رئيسي
│   ├── public/              # الملفات الثابتة
│   └── index.html           # HTML الرئيسي
├── package.json             # المتطلبات والأوامر
├── vite.config.ts           # إعدادات Vite
└── tsconfig.json            # إعدادات TypeScript
```

---

## تخصيص الموقع

### تغيير الألوان
- افتح: `client/src/index.css`
- ابحث عن `@theme inline` و `--color-primary`
- غير القيم حسب رغبتك

### تغيير المحتوى
- **Hero Section:** `client/src/components/sections/Hero.tsx`
- **About Section:** `client/src/components/sections/About.tsx`
- **Skills Section:** `client/src/components/sections/Skills.tsx`
- **Projects Section:** `client/src/components/sections/Projects.tsx`

### إضافة صورة شخصية
1. ضع الصورة في: `client/public/profile.jpg`
2. افتح: `client/src/components/sections/Hero.tsx`
3. أضف الصورة في القسم المناسب

---

## نشر الموقع

### نشر على GitHub Pages (مجاني)
```bash
npm run build
git add .
git commit -m "Deploy to GitHub Pages"
git push origin main
```

### نشر على Vercel
1. اذهب إلى: https://vercel.com
2. اضغط "New Project"
3. اختر مستودعك من GitHub
4. اضغط "Deploy"

### نشر على Netlify
1. اذهب إلى: https://netlify.com
2. اضغط "New site from Git"
3. اختر مستودعك
4. اضغط "Deploy"

---

## الدعم والمساعدة

إذا واجهت مشاكل:
1. تحقق من Console في Developer Tools (F12)
2. اقرأ رسالة الخطأ بعناية
3. ابحث عن الخطأ على Google
4. تأكد من تثبيت جميع المتطلبات

---

## معلومات إضافية

- **التكنولوجيا المستخدمة:** React 19, Tailwind CSS 4, Framer Motion
- **المتصفحات المدعومة:** Chrome, Firefox, Safari, Edge
- **الاستجابة:** متوافق تماماً مع الهواتف والأجهزة اللوحية

---

**تم! استمتع بموقعك الجديد! 🚀**
